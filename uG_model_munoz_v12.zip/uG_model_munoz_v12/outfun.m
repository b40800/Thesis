function stop = outfun(x,optimValues,state)
% OUTFUN  At every iteration of fminunc, this function monitors the partial
%         results and stops fminunc when desired values are reached

stop = false;

if optimValues.fval < 1e-3
    stop = true;
end

end