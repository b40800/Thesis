% MAIN  This script contains the program flow of a simulation of a microgrid
%       and the power flow at its interface (VSI) with the utility Grid.
%       The state space representation of a Simulink model is obtained.
%       Power flow equation system is solved, a P/U Droop control is
%       applied to the specified controlable units. Also, an optimization of 
%       the VSI voltage is achieved by minimizing a function using fminunc. 

global H H_in

init_sim;                                                  	% initialization of all parameters

if compute_H 
    [H, H_in] = compute_H_matrix('uGrid_model_R_30');      	% compute admitance matrix H 
    save('H_matrix_30.mat','H','H_in');                     % store admitance matrix 
else
    load('H_matrix_30.mat');                            	% load previous admitance matrix 
end

%% VSI Optimization block
if opt_VSI && active_VSI
    x0 = [angle(U0(2)), abs(U0(2))];
    options = optimoptions(@fminunc,'Algorithm','quasi-newton','OutputFcn',@outfun,'SpecifyObjectiveGradient',false,...
                            'Display','iter-detailed','MaxIterations',200,'MaxFunctionEvaluations',1000,...
                            'StepTolerance', 1e-6,'FunctionTolerance',1e-3)
                     
    [x,fval,exitflag,output]= fminunc(@(x)objfun(x,S0,U0), x0, options);
    
    U0(2) = x(2)*exp(1i*x(1));                            	% set optimal voltage of Inverter
end
%%

S_in    = S0;
U_in    = U0;

for ind1=1:droop_iter
    
    [U1,S1,S_histo] = power_flow_state(U_in, S_in, pflow_iter, sim_tol);
    I1 = H*U1;
    
    S2 = droop_control(U1,S1);
    
    store_data_iter                                      	% collecting data every iteration

    if ( max( abs(abs(S1)-abs(S2)) ) <= sim_tol)...  
            && ( max( abs(abs(U1)-abs(U_in))) <= sim_tol)
        break;
    end
    
    S1_c = conj(S1);                                       	% initial values for next power_flow run 
    S2_c = conj(S2);
    U1_c = conj(U1);                                                
    U_in(3:end)=H_in*( ( S2_c(3:end)-S1_c(3:end) ) ./ U1_c(3:end) ) + U1(3:end);
    S_in = S2;

end

display_results;                                           	% Display the results (plots, tables, etc)
