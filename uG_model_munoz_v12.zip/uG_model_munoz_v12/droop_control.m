function S_o = droop_control(U_i, S_i)
% DROOP_CONTROL  This fuction manages the droop of the controllable units.
%                Take U(Ctrl_units) and modifies S(Ctrl_units) according to
%                parameters described in the initialization section.

global u0 p0_DG p0_ES Kp Kp_ES Ctrl_DGs Ctrl_ESs Ctrl_Unit_p cpwr_band

% Droop 1: Fully dispatchable DG units
if ~isempty(Ctrl_DGs)
    P = p0_DG - Kp.*(abs(U_i(Ctrl_DGs))-u0);
    Q = imag(S_i(Ctrl_DGs));
    S_i(Ctrl_DGs) = P+1i*Q;
end

% Droop 2: Fully dispatchable ES units
if ~isempty(Ctrl_ESs)
    P = p0_ES - Kp_ES.*(abs(U_i(Ctrl_ESs))-u0);
    Q = imag(S_i(Ctrl_ESs));
    S_i(Ctrl_ESs) = P+1i*Q;
end

% Droop 3: Partially dispatchable DG units
% Note: if a cpwr_band of 0% is selected, droop 3 is equivalent to droop 1
if ~isempty(Ctrl_Unit_p)
    
   if ( U_i(Ctrl_Unit_p(1)) < (u0-cpwr_band*u0/2) )                              % if within constant band -b
        P = p0_DG - Kp.*(abs(U_i(Ctrl_Unit_p))-(u0-cpwr_band*u0/2));
        Q = imag(S_i(Ctrl_Unit_p));
        S_i(Ctrl_Unit_p) = P+1i*Q;

    elseif ( U_i(Ctrl_Unit_p(1)) > (u0+cpwr_band*u0/2) )                          % if within constant band +b
        P = p0_DG - Kp.*(abs(U_i(Ctrl_Unit_p))-(u0+cpwr_band*u0/2)); 
        Q = imag(S_i(Ctrl_Unit_p));
        S_i(Ctrl_Unit_p) = P+1i*Q;
   end
end

S_o = S_i;

end