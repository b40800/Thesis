from PIL import Image
import os, sys

def resizeImage(infile, output_dir="", size=(1024,600)):
     print infile

     if "resized" not in infile:
        try :
            im = Image.open(infile)
            im.thumbnail(size, Image.ANTIALIAS)
            im.save(os.path.join(output_dir,infile),"PNG")
        except IOError:
            print "cannot reduce image for ", infile


if __name__=="__main__":
    root = os.path.dirname(os.path.abspath(__file__))
    for rel_root, dirs, files in os.walk(root):
        for file in files:
            if ".png" in file:
                abs_path = os.path.join(root,rel_root[2:])
                if "droop" in file or "debug" in file:
                    resizeImage(os.path.join(abs_path,file),"",(454,273))
                elif "3D" not in file:
                    resizeImage(os.path.join(abs_path,file),"",(573,338))
            