%INIT_SIM  Choose initial state of variables and configuration options

global  u0 w P_Load S_DG pflow_iter droop_iter sim_tol display_debug ...
        compute_H len_Line active_VSI opt_VSI opt_val phi ...
        p0_DG p0_ES Kp Kp_ES Ctrl_DGs Ctrl_ESs Ctrl_Unit_p ...
        droop_DG droop_ES droop_Part cpwr_band ...
        new_plot append_plot display_plot test_name lgd_loc51 lgd_loc52

%% Computing options                    % True = 1; False = 0
% These variables are private, can only be set in this script
num_units       = 30;                  	% Total number of units in analyzed model
plot_xunits     = 1;                    % Number of units to plot (per type)   
display_debug	= 0;                    % Plot of power flow (set opt_Pinv = 0, droop_iter = 1) 
pflow_iter      = 50;                   % Max iterations for power_flow_state algorithm
droop_iter      = 200;                  % Max iterations for main loop
sim_tol         = 0.1;                  % Tolerance value for termination criterias

% These variables are public, have a default value and can be set by external scripts 
if isempty(compute_H) 
    compute_H       = 0;                % Analyze Simulink model to compute new H matrix 
end
if isempty(len_Line) 
    len_Line      	= 100;              % Length (in meters) of line type 2 in Simulink model
end
if isempty(active_VSI) 
    active_VSI    	= 0;          		% Run simulation without VSI (by setting voltage to zero)
end
if isempty(opt_VSI) 
    opt_VSI         = 0;              	% Run optimization for VSI 
end
if isempty(opt_val) 
    opt_val         = 0;                % Set reference value for active power flow
end
if isempty(P_Load) 
    P_Load          = -8000;            % Initial apparent power for Load units (negative values)
end
if isempty(S_DG) 
    S_DG            = 10000 - 1000i;   	% Initial apparent power for DG units (P must be set to Nominal)
end
if isempty(droop_DG) 
    droop_DG        = 1;                % Activate droop control for DG units
end
if isempty(droop_ES) 
    droop_ES        = 0;                % Activate droop control for ES units
end
if isempty(droop_Part)                  
    droop_Part      = 0;                % Activate droop control for partially-controllable units
end
if isempty(cpwr_band) 
    cpwr_band      = 0.1;               % Default constant-power band 2b = 10% (centered at nominal point)
end
if isempty(new_plot) 
    new_plot        = 0;                % Start a new appendable plot
end
if isempty(append_plot) 
    append_plot     = 0;                % Append to previous plot
end
if isempty(display_plot) 
    display_plot   	= 0;                % Display all plots (except debug plot)
end
if isempty(test_name) 
    test_name       = 'case';           % Default plot name
end
if isempty(lgd_loc51)
    lgd_loc51 = 'east';                 % Position of legends in plot 5 (subplots 51 and 52)
    lgd_loc52 = 'east';
end

%% SIMULINK parameters
freq        = 50;    
ang_freq    = 2*pi*freq;
u0          = 230;
R0          = 0.642/1000;               % Resistance per meter
X0          = 0.083/1000;               % Reactance per meter
l2          = len_Line;               	% Length of PCC lines 
R_type_2    = R0*l2;
L_type_2    = (X0/ang_freq)*l2;
l3          = 1;                        % length of household lines 
R_type_3    = R0*l3;
L_type_3    = (X0/ang_freq)*l3;

%% Initial operating conditions
w               = ang_freq;
S0              = ones(num_units+2,1);
S0(1:2)         = 0;                    % initial guess for S of Grid and VSI
S0(3:3:end-2)   = S_DG;                 % set initial value of S for every DG unit
S0(4:3:end-1)   = P_Load;               % set initial value of S for every variable Load unit
S0(5:3:end)     = 0;                    % set initial value of S for every ES unit (must be set to zero)
U0              = ones(size(S0))*u0;    % initial guess for voltage of every unit                                 

%% Voltage Inverter (VSI)   
% Choose phase offset between voltage and current at VSI
if (abs(real(S0(3)))>abs(real(P_Load)))	% if |P_DG| > |P_Load|
    phi = pi/2;
else
    phi = 3*pi/2;
end
% Default magnitude and phase of voltage at VSI
if active_VSI
    amp         = 10;
    p_rad       = phi - pi/2;         	% start at 0 or pi radians, depending on load conditions
    U0(2)       = amp*exp(1i*p_rad);    % initial value of magnitude and phase of inverter
else
    U0(2) = 0;
end

%% P/U droop characteristics                
u_min       = 0.9*u0;
u_max       = 1.1*u0;

% droop characteristics DG
if droop_DG
    p0_DG       = real(S0(3));                      % Value used by droop function
    p_nom       = 10000;                            % Nominal operation power of DG units.
    Kp          = p_nom/50;                        % Rate of change of P/U droop
    Ctrl_DGs    = 3:3:length(S0)-2;                 % Indexes of Fully dispatchable units (DG1..DGn)
end

% droop characteristics DG (partially-dispatchable)
% Note: the indexes for this type of unit can vary from the previous droop 
if droop_Part
    p0_DG       = real(S0(3));                      % Value used by droop function (most be equal to P_nom)
    p_nom       = 10000;                            % Nominal operation power of DG units.
    Kp          = p_nom/50;                         % Rate of change of P/U droop
    Ctrl_Unit_p = 3:3:length(S0)-2;                 % Indexes of partially-dispatchable units (DG1..DGn)
end

% droop characteristics ES
if droop_ES
    p0_ES       = real(S0(5));
    p_max       = 5000;                             % Positive operation power of ES units. Used only to determine Kp
    p_min       = -5000;                            % Negative operation power of ES units. Used only to determine Kp
    Kp_ES       = (p_max-p_min)/50;                % Rate of change of P/U droop
    Ctrl_ESs    = 5:3:length(S0);                   % Indexes of Fully dispatchable units (ES1..ESn)
end

%% Plotting variables
% PCC
U_pcc       = zeros(1,1);
U_pcc(1)    = U0(1);
P_pcc       = zeros(1,1);
P_pcc(1)    = sum(real(S0(3:end)));
Q_pcc       = zeros(1,1);
Q_pcc(1)    = sum(imag(S0(3:end)));

% Power VSI
P_Inv       = zeros(1,1);
P_Inv(1)    = real(S0(2));
Q_Inv       = zeros(1,1);
Q_Inv(1)    = imag(S0(2));
% Phase VSI
a_Uinv      = zeros(1,1);
a_Iinv      = zeros(1,1);

% Household Units
U_unit        = zeros(plot_xunits*3+1,1);
P_unit        = zeros(plot_xunits*3+1,1);
U_unit(:, 1)  = U0(3:3+plot_xunits*3);
P_unit(:, 1)  = real(S0(3:3+3*plot_xunits));

