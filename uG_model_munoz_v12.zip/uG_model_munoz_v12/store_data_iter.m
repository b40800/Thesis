
% Saves results of every iteration

% PCC
U_pcc(end+1)  = sum(U1(3:end))/length(U1(3:end));     
P_pcc(end+1)  = sum(real(S2(3:end)));
Q_pcc(end+1)  = sum(imag(S2(3:end)));

% Inverter
P_Inv(end+1)  = real(S2(2));
Q_Inv(end+1)  = imag(S2(2));
a_Uinv(end+1) = angle(U1(2));
a_Iinv(end+1) = angle(I1(2));

% Household Unit
U_unit(:, end+1) = U1(3:3+3*plot_xunits);
P_unit(:, end+1) = real(S2(3:3+3*plot_xunits));
