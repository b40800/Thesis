% Case scenario 432: Reactive power

close all; clear all;
% Case 1
% Initial state (no VSI, droop_DG) 
opt_val         = 14000;               % this value is close to the worst case scenario
save_clear      = 1;
save_appnd      = 0;
disp_plots      = 0;

main

% Update variables with required value 
active_VSI     	= 1;                        % operate with VSI               
opt_Pinv        = 1;    
save_clear      = 0;
disp_plots      = 1;          
mkdir('./study_cases/case_433_reactive_power');
test_name       = './study_cases/case_433_reactive_power/case_433_1';
lgd_loc51 = 'southeast';
lgd_loc52 = 'northeast';

main


close all; clear all;
% Case 2
% Initial state (no VSI, droop_DG) 
opt_val         = -14100;               % this value is close to the worst case scenario -14030
save_clear      = 1;
save_appnd      = 0;
disp_plots      = 0;                    

main

% Update variables with required value 
active_VSI     	= 1;                        % operate with VSI              
opt_Pinv        = 1;  
save_clear      = 0;
disp_plots      = 1;          
test_name       = './study_cases/case_433_reactive_power/case_433_2';
lgd_loc51 = 'northeast';
lgd_loc52 = 'southeast';

main
