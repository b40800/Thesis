% Case scenario 4: Adjustment of net power flow
close all; clear all;
% Case 1
% Initial state (no VSI, droop_DG)
P_Load          = -7000;                    % starting Load power (consider S_DG0 = 10000-1300i)
new_plot        = 1;                        % start new plot
append_plot  	= 0;                        % do not append to previous plot    
display_plot  	= 0;                        % do not display plots 

main

% Update variables with required value 
active_VSI    	= 1;                        % operate with VSI 
opt_VSI         = 1;                        % VSI-optimization is active (opt_val=0 is default)
new_plot        = 0;                        % start new plot
append_plot  	= 1;                        % append to previous plot    

main

% Case 2
% Update variables with required value 
opt_val         = 10000;                    % set new reference P_grid value

main

% Case 3
% Update variables with required value 
opt_val         = 20000;                    % set new reference P_grid value
append_plot  	= 1;                        % append to previous plot    
display_plot    = 1;                        % display all plots

% Conditions for saving displayed plots
mkdir('./study_cases/case_4_adjustment_net_load');
test_name       = './study_cases/case_4_adjustment_net_load/case_4_1';

main


close all; clear all;
% Case 1
% Initial state (no VSI, droop_DG)
P_Load          = -13000;                    % starting Load power (consider S_DG0 = 10000-1300i)
new_plot        = 1;                        % start new plot
append_plot  	= 0;                        % do not append to previous plot    
display_plot  	= 0;                        % do not display plots 

main

% Update variables with required value 
active_VSI    	= 1;                        % operate with VSI 
opt_VSI         = 1;                        % VSI-optimization is active (opt_val=0 is default)
new_plot        = 0;                        % start new plot
append_plot  	= 1;                        % append to previous plot    

main

% Case 2
% Update variables with required value 
opt_val         = -10000;                    % set new reference P_grid value

main

% Case 3
% Update variables with required value 
opt_val         = -20000;                    % set new reference P_grid value
append_plot  	= 1;                        % append to previous plot    
display_plot    = 1;                        % display all plots

% Conditions for saving displayed plots
test_name       = './study_cases/case_4_adjustment_net_load/case_4_2';

main