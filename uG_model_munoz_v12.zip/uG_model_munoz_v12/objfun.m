function [f,g] = objfun(x,S_in,U_in)
% OBJFUN  At every iteration of fminunc, this function runs power flow and droop.
%         It uses the input values of x to adjust phase and magnitude of U(2)
%         It outputs a function, designed to achieve optimal operating conditions 
%         of inverter, as the function tends to a minimum(limited to zero)
%         See FMINSEARCH's arguments for anonymous functions.

global H H_in phi droop_iter pflow_iter sim_tol opt_val

U_in(2) = x(2)*exp(1i*x(1));

for ind1=1:droop_iter
    
    [U1,S1,S_histo] = power_flow_state(U_in, S_in, pflow_iter, sim_tol);
    
    S2 = droop_control(U1,S1);

    if ( max( abs(abs(S1)-abs(S2)) ) <= sim_tol)...  
            && ( max( abs(abs(U1)-abs(U_in))) <= sim_tol)
        break;
    end
    
    S1_c        = conj(S1);
    S2_c        = conj(S2);
    U1_c        = conj(U1);                                               
    U_in(3:end) = H_in*( ( S2_c(3:end)-S1_c(3:end) ) ./ U1_c(3:end) ) + U1(3:end);
    S_in        = S2;

end

I1 = H*U1;

% OPTIMIZATION 1: Pinv --> 0 and Pgrid --> Pset
C_rg = 1e6;
if phi == pi/2
    f = C_rg*( x(1) - angle(I1(2)) - phi)^2 + (real(S2(1)) + opt_val)^2;    % Ppcc = opt_val
else
    f = C_rg*( x(1) - angle(I1(2)) - phi)^2 + (real(S2(1)) + opt_val)^2;    % Ppcc = opt_val
end
    
end