%DISPLAY_RESULTS  Collects data and present results in continuous-like plots

%% Store data in files for subsequent use
if new_plot
    U_pcc_0 = U_pcc; P_pcc_0 = P_pcc; Q_pcc_0 = Q_pcc;
    save('PCC_0.mat','U_pcc_0','P_pcc_0','Q_pcc_0')
    
    U_unit_0  = U_unit; P_unit_0  = P_unit;
    save('unit_0.mat','U_unit_0','P_unit_0')
    
elseif append_plot
    load('PCC_0.mat')
    U_pcc_m = U_pcc; P_pcc_m = P_pcc;
    U_pcc_m(1) = U_pcc_0(end); P_pcc_m(1) = P_pcc_0(end);               % merge iterations for plot continuity
    U_pcc_0 = [U_pcc_0 U_pcc_m];
    P_pcc_0 = [P_pcc_0 P_pcc_m];
    save('PCC_0.mat','U_pcc_0','P_pcc_0')
    
    load('unit_0.mat')
    U_unit_m = U_unit; P_unit_m = P_unit;
    U_unit_m(:,1) = U_unit_0(:,end); P_unit_m(:,1) = P_unit_0(:,end);   % merge iterations for plot continuity
    U_unit_0  = [U_unit_0 U_unit_m];
    P_unit_0  = [P_unit_0 P_unit_m];
    save('unit_0.mat','U_unit_0','P_unit_0')
end

%% Table of results
U0_abs      = abs(U0);
P0          = real(S0);
Q0          = imag(S0);
U1_abs      = abs(U1);
P2          = real(S2);
Q2          = imag(S2);
I1_re       = real(I1);
I1_im       = imag(I1);

table_1 = table(U0_abs,P0,Q0,U1_abs,P2,Q2,I1_re,I1_im);
disp(table_1);

% Final state
U_pcc_final = U_pcc(end)
P_pcc_final = P_pcc(end)

%% Plot for debug case: power flow algorithm
if display_debug
    % Table of results
    P1 = real(S1);
    Q1 = imag(S1);
    table_dbg = table(U0,P0,Q0,U1,P1,Q1,I1_re,I1_im);
    disp(table_dbg);
    mkdir('./study_cases/case_debug');
    writetable(table_dbg,'./study_cases/case_debug/table_results.xlsx');
    % Plot
    figure('Position', [100 50 1000 600]);
    subplot('position',[0.11 0.13 0.87 0.80]);
    x = 1:length(S_histo);
    plot(x,real(S_histo)/1000,'LineWidth',2.5);
    grid on; set(gca,'Fontsize',18,'xtick',x);
    xlabel('Iteration Number'); ylabel('Active Power [ kW ]');
    lgd = legend('P_G_R_I_D');
    lgd.Location = 'east'; lgd.FontSize = 17;
    saveas(gcf, './study_cases/case_debug/case_debug.png') 
end

%% Plot 1: Voltage Inverter (plot last run, no appended plot)
if display_plot
    if active_VSI
        x_axis  = 1:length(P_Inv);
        n = length(x_axis);
        Uinv = ones(1,n)*U1(2);
        % Magnitude
        figure('Position', [100 50 1000 600]);
        subplot('position',[0.09 0.56 0.89 0.4]);
        plot(x_axis,real(Uinv),'LineWidth',1.5); grid on;
        xlim([1 x_axis(end)]);
        set(gca,'XTickLabel',[],'Fontsize',14); ylabel('Voltage [ V ]');
        if x_axis(end) < 31
            set(gca,'xtick',1:x_axis(end))
        end
        lgd = legend('Real( U_V_S_I )');
        lgd.Location = 'northeast'; lgd.FontSize = 14; 


        % Phase
        subplot('position',[0.09 0.11 0.89 0.4]);
        Uphase = wrapTo2Pi(a_Uinv)*(180/pi);
        a_diff_deg = wrapTo2Pi(a_Uinv-a_Iinv)*(180/pi);
        plot(x_axis,Uphase,'LineWidth',1.5); hold on;
        plot(x_axis,a_diff_deg,'LineWidth',1.5); grid on;
        set(gca,'Fontsize',15); 
        if x_axis(end) < 31
            set(gca,'xtick',1:x_axis(end))
        end
        ylim([-20 360]); xlim([1 x_axis(end)]);
        xlabel('Iteration Number'); ylabel('Phase [ deg ]');
        lgd = legend('angle( U_V_S_I )','Phi_V_S_I');
        lgd.Location = 'northeast'; lgd.FontSize = 14; 

        saveas(gcf, strcat(test_name,'_1.png'))
    
    %% Plot 2: Power of Inverter (plot last run, no appended plot)
        figure('Position', [100 50 1000 600]);
        subplot('position',[0.09 0.56 0.89 0.4]);
        plot(x_axis,P_Inv,'LineWidth',1.5); grid on;
        set(gca,'XTickLabel',[],'Fontsize',15);
        if x_axis(end) < 31
            set(gca,'xtick',1:x_axis(end))
        end
        ymax = max(P_Inv); ymin = min(P_Inv);
        deltay = ymax - ymin;
        ylim([ymin-deltay ymax+deltay]); xlim([1 x_axis(end)]);
        ylabel('Active Power [ W ]');
        lgd = legend('P_V_S_I');
        lgd.Location = 'northeast'; lgd.FontSize = 14; 

        % Pinv, Qinv vs Iter 
        subplot('position',[0.09 0.11 0.89 0.4]);
        plot(x_axis,Q_Inv,'LineWidth',1.5); grid on;
        set(gca,'Fontsize',15);
        if x_axis(end) < 31
            set(gca,'xtick',1:x_axis(end))
        end
        ymax = max(Q_Inv); ymin = min(Q_Inv);
        deltay = ymax - ymin;
        ylim([ymin-deltay ymax+deltay]); xlim([1 x_axis(end)]);
        xlabel('Iteration Number'); ylabel('Reactive Power [ var ]');
        lgd = legend('Q_V_S_I');
        lgd.Location = 'northeast'; lgd.FontSize = 14; 
        saveas(gcf, strcat(test_name,'_2.png'))
    end
%% Plot 3: PCC (appendable plot)
    load('PCC_0.mat')
    n1 = size(U_pcc_0, 2);                                      % Number of iteration (columns)
    x1 = 1:n1;
   
    figure('Position', [100 50 1000 600]); 
    subplot('position',[0.09 0.56 0.89 0.4]);
    plot(x1,abs(U_pcc_0),'LineWidth',1.5); grid on; 	% U_PCC
    ymax = max(abs(U_pcc_0));
    ymin = min(abs(U_pcc_0));
    deltay = ymax-ymin;
    ylim([ymin-deltay/10 ymax+deltay/10]); xlim([1 x1(end)]);
    set(gca,'XTickLabel',[],'Fontsize',15); ylabel('Voltage [ V ]');
    if x1(end) < 31
        set(gca,'xtick',1:x1(end))
    end
    lgd = legend('U_P_C_C'); 
    lgd.Location = 'east'; lgd.FontSize = 14; 
    
    subplot('position',[0.09 0.11 0.89 0.4]);
    plot(x1, P_pcc_0/1000,'LineWidth',1.5); grid on;            	% P_PCC
    set(gca,'Fontsize',15);
    if x1(end) < 31
        set(gca,'xtick',1:x1(end))
    end
    ymax = max(P_pcc_0/1000);
    ymin = min(P_pcc_0/1000);
    deltay = ymax-ymin;
    ylim([ymin-deltay/10 ymax+deltay/10]); xlim([1 x1(end)]);
    xlabel('Iteration Number'); ylabel('Active Power [ kW ]');
    lgd = legend('P_P_C_C'); 
    lgd.Location = 'east'; lgd.FontSize = 14;
    saveas(gcf, strcat(test_name,'_3.png'))
    
%% Plot 4: P-U droop of controllable units (plot last run, no appended plot)
    figure('Position', [100 50 1000 600]);
    subplot('position',[0.11 0.13 0.87 0.80]);
    
    idx_DG  = 1;                              	% DG fully controllable are in 1,7,13 .. 
    idx_ES  = 3;                              	% ES fully controllable are in 3,9,15 .. 
    idx_DGp = 4;                              	% DG partially controllable are in 4,10,16 ..

    if abs(real(S0(3))) > abs(real(S0(4)))  % This sorting it is needed to plot constant-voltage bands
        U_unit_s = sort(U_unit,2);
        P_unit_s = sort(P_unit,2,'descend');
    else
        U_unit_s = sort(U_unit,2,'descend');
        P_unit_s = sort(P_unit,2);
    end
    
    for idx=1:plot_xunits
       
        if droop_DG
            plot(abs(U_unit_s(idx_DG,:)),P_unit_s(idx_DG,:),'LineWidth',2.5); hold on;  
        end
        if droop_ES
            plot(abs(U_unit_s(idx_ES,:)),P_unit_s(idx_ES,:),'LineWidth',2.5); hold on;   
        end
        if droop_Part
            % From initial voltage to second value, go volt by volt
            U_unit_initial = floor(abs(U_unit_s(idx_DGp,1)));
            U_unit_cb = U_unit_initial:1:U_unit_initial + cpwr_band*u0/2;     % create virtual voltage band
            U_unit_plot = [U_unit_cb abs(U_unit_s(idx_DGp,2:end))];
            len_cb = length(U_unit_cb);
            len_plot = length(U_unit_plot);
            
            P_unit_cb = zeros(1, len_cb);                                   % constant power in virtual voltage band                                       
            P_unit_cb(1:len_cb) = P_unit_s(idx_DGp,1);
            P_unit_plot = [P_unit_cb P_unit_s(idx_DGp,2:end)];
            
            plot(U_unit_plot,P_unit_plot,'LineWidth',2.5); hold on;  
        end
        idx_DG  = idx_DG + 6;
        idx_ES  = idx_ES + 6;
        idx_DGp = idx_DGp + 6;
    end
    
    if droop_ES                                                             % Consider ES for plot limits
        P_all_units = [P_unit(1,:) P_unit(3,:) P_unit(4,:)];
    else
        P_all_units = [P_unit(1,:) P_unit(4,:)];
    end
    
    grid on; set(gca,'Fontsize',18);
    xmin = min(abs(U_unit(1,:))); xmax = max(abs(U_unit(1,:)));
    ymin = min(P_all_units);                                        % Consider 3 units (sometimes different types)
    ymax = max(P_all_units);
    deltax = xmax-xmin; deltay = ymax-ymin;
    if (droop_DG + droop_ES + droop_Part) > 1                       % If more than one type of controllable unit
        xlim([xmin xmax+deltax/10]); ylim([ymin-deltay/16 ymax+deltay/16]);
    else
        xlim([xmin xmax+deltax/10]); ylim([ymin-deltay/6 ymax+deltay/8]);
    end
    xlabel('Voltage [ V ]'); ylabel('Active Power [ W ]');
    lgd = legend('Unit 1','Unit 2','Unit 3');
    lgd.Location = 'east'; lgd.FontSize = 17; 
    
    saveas(gcf, strcat(test_name,'_4_droop.png'))
    
    %% Plot 5: U and P of units (appendable plot)
    load('unit_0.mat')
    figure('Position', [100 50 1000 600]);
    % Voltage in controllable units
    subplot('position',[0.09 0.56 0.89 0.4]);
    %U_unit(:,1) = U_unit_0(:,end);           	% merge iterations for plot continuity
    idx_DG  = 1;                             	% DG fully controllable are in 1,7,13 .. 
    idx_ES  = 3;                             	% ES fully controllable are in 3,9,15 .. 
    idx_DGp = 4;                              	% DG partially controllable are in 4,10,16 ..
    for idx=1:plot_xunits

        if droop_DG
            plot(x1,abs(U_unit_0(idx_DG,:)),'LineWidth',1.5);
            hold on;
        end
        if droop_ES
            plot(x1,abs(U_unit_0(idx_ES,:)),'LineWidth',1.5);
            hold on;   
        end
        if droop_Part
            plot(x1, abs(U_unit_0(idx_DGp,:)),'LineWidth',1.5);
            hold on; 
        end
        idx_DG  = idx_DG + 6;
        idx_ES  = idx_ES + 6;
        idx_DGp = idx_DGp + 6;
    end
    
    grid on; set(gca,'XTickLabel',[],'Fontsize',15);
    if x1(end) < 31
        set(gca,'xtick',1:x1(end))
    end
    ymax = max(abs(U_unit_0(1,:)));
    ymin = min(abs(U_unit_0(1,:)));
    deltay = ymax-ymin;
    ylim([ymin-deltay/8 ymax+deltay/8]); xlim([1 x1(end)]);
    ylabel('Voltage [ V ]');
    lgd = legend('Unit 1','Unit 2','Unit 3');
    lgd.Location = lgd_loc51; lgd.FontSize = 14;
    hold off;
    
    % Active Power in cotrollable units
    subplot('position',[0.09 0.11 0.89 0.4]);
    idx_DG  = 1;                               	% DG fully controllable are in 1,7,13 .. 
    idx_ES  = 3;                               	% ES fully controllable are in 3,9,15 .. 
    idx_DGp = 4;                               	% DG partially controllable are in 4,10,16 ..
    for idx=1:plot_xunits

        if droop_DG
            plot(x1,P_unit_0(idx_DG,:)/1000,'LineWidth',1.5);
            hold on;
        end
        if droop_ES
            plot(x1,P_unit_0(idx_ES,:)/1000,'LineWidth',1.5);
            hold on;   
        end
        if droop_Part
            plot(x1,P_unit_0(idx_DGp,:)/1000,'LineWidth',1.5);
            hold on; 
        end
        idx_DG  = idx_DG + 6;
        idx_ES  = idx_ES + 6;
        idx_DGp = idx_DGp + 6;
    end
    grid on; set(gca,'Fontsize',15);
    if x1(end) < 31
        set(gca,'xtick',1:x1(end))
    end
    
    if droop_ES                                                             % Consider ES for plot limits
        P_all_units = [ (P_unit_0(1,:)) (P_unit_0(3,:)) (P_unit_0(4,:)) ];
    else
        P_all_units = [ (P_unit_0(1,:)) (P_unit_0(4,:)) ];
    end
    ymax = max(P_all_units/1000);
    ymin = min(P_all_units/1000);
    deltay = ymax-ymin;
    ylim([ymin-deltay/8 ymax+deltay/8]); xlim([1 x1(end)]);
    xlabel('Iteration Number'); ylabel('Active Power [ kW ]');
    lgd = legend('Unit 1','Unit 2','Unit 3');
    lgd.Location = lgd_loc52; lgd.FontSize = 14;
    
    saveas(gcf, strcat(test_name,'_5.png'))
    hold off;

end

% Verify voltage limits
Udiff = abs(abs(U1(1)) - abs(U1(3:end)));                       % Upcc = Uunits ; Udiff = Ugrid - Uunits
if (max(Udiff) > 0.1*abs(U1(1)) )                               % limits are +-0.1Unominal
    fprintf('SIMULATION EXCEEDED VALID VOLTAGE LIMITS!\n')
end











