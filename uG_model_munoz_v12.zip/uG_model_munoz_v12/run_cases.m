% Run cases

% Case 0: VSI optimization and effect of droop control 
case_0
fprintf('Case_0 was completed successfully!\n')

% Case 1: Distributed Generation exceeds Load demand
case_1
fprintf('Case_1 was completed successfully!\n')

% Case 2: Load demand exceeds Distributed Generation
case_2
fprintf('Case_2 was completed successfully!\n')

% Case scenario 4: Adjustment of net power flow
case_4
fprintf('Case_4 was completed successfully!\n')

% Case 5: Controller reacts to Generation/Load changes
case_5
fprintf('Case_5 was completed successfully!\n')

% Case 6: Partially dispatchable Units
case_6
fprintf('Case_6 was completed successfully!\n')

% Case 7: Partially dispatchable Units with extra storage systems
case_7
fprintf('Case_7 was completed successfully!\n')

% Case 431: PCC voltage out of limits
case_431
fprintf('Case_431 was completed successfully!\n')

% Case 432: Length of distribution lines
%case_432
fprintf('Case_431 was completed successfully!\n')

% Case 432: Reactive power limits
%case_433
fprintf('Case_432 was completed successfully!\n')
