% test limits of reactive power
clear all; close all;

% Select test and/or plot
% Case 1
run_test_c1  = 0;
show_plot_c1 = 1;
% Case 2
run_test_c2  = 0;
show_plot_c2 = 1;

% Case 1: Test controllability for P_DG > P_Load
% Initial state
no_VSI          = 0;                        % operate with VSI
opt_VSI         = 1;                        % VSI with default values (no optimization)
P_Load          = -7000;                    % starting Load power (consider S_DG0 = 10000-1300i)
droop_main      = 1;                        % main droop active 

% Test power range vs reactive power variation 
if run_test_c1                                   
    Pinv_3D_c1 = zeros(1,1);
    j = 0;
    for Q = -2000:100:500
        j = j+1;
        i = 0;
        for opt_val = 0:1000:30000
            i = i+1;
            S_DG   = 10000 + Q*1i;              % set initial value of S for every DG unit
            main
            if abs(real(S2(2))) < 5000                                 % limit value to +-10k
                Pinv_3D_c1(j,i) = real(S2(2));
            else
                Pinv_3D_c1(j,i) = 5000*real(S2(2))/abs(real(S2(2)));   % replace value for 10kW or -10kW
            end
        end
    end

    save('limits_Q_c1.mat','Pinv_3D_c1')
end

if show_plot_c1
    % Plot 1
    load('limits_Q_c1.mat')
    figure;
    X = 0:1:30;                 % Power reference
    Y = -2000:100:500;         % Reactive power consumption (negative) per household
    Z = Pinv_3D_c1;             % Active power VSI
    surf(X,Y,Z)
    set(gca,'Fontsize',12) 
    xlabel('X [ kW ]'); ylabel('Y [ var ]'); zlabel('Z [ W ]');
    saveas(gcf, './study_cases/case_433_reactive_power/case_Q_lim_3D_c1.png')
end


% Case 2: Test controllability for P_Load > P_DG
% Initial state
no_VSI          = 0;                        % operate with VSI
opt_VSI         = 1;                        % VSI with default values (no optimization)
P_Load          = -13000;                    % starting Load power (consider S_DG0 = 10000-1300i)
droop_main      = 1;                        % main droop active 

% Test power range vs reactive power variation 
if run_test_c2                                   
    Pinv_3D_c2 = zeros(1,1);
    j = 0;
    for Q = -2000:100:500
        j = j+1;
        i = 0;
        for opt_val = 0:-1000:-30000
            i = i+1;
            S_DG   = 10000 + Q*1i;              % set initial value of S for every DG unit
            main
            if abs(real(S2(2))) < 5000                                 % limit value to +-10kW
                Pinv_3D_c2(j,i) = real(S2(2));
            else
                Pinv_3D_c2(j,i) = 5000*real(S2(2))/abs(real(S2(2)));   % replace value for 10kW or -10kW
            end
        end
    end

    save('limits_Q_c2.mat','Pinv_3D_c2')
end

if show_plot_c2
    % Plot 1
    load('limits_Q_c2.mat')
    figure;
    X = 0:-1:-30;                                	
    Y = -2000:100:500;         % Reactive power consumption (negative) per household    
    Z = Pinv_3D_c2;
    surf(X,Y,Z)
    set(gca,'Fontsize',12) 
    xlabel('X [ kW ]'); ylabel('Y [ var ]'); zlabel('Z [ W ]');
    saveas(gcf, './study_cases/case_433_reactive_power/case_Q_lim_3D_c2.png')
end