% Case scenario 6: Partially dispatchable Units
close all; clear all;
% Initial state (no VSI) 
P_Load          = -8500;                    % starting Load power (consider S_DG0 = 10000-1300i)
droop_DG        = 0;                        % unselect droop_DG 
droop_Part      = 1;                        % select droop_DG for partially-dispatchable units
cpwr_band       = 0.1;                      % select constant-power band (as percentage of U_nominal)
new_plot        = 1;                        % start new plot
append_plot  	= 0;                        % do not append to previous plot    
display_plot  	= 0;                        % do not display plots 

main

% Update variables with required value 
active_VSI      = 1;                        % operate with VSI
opt_VSI         = 1;                        % VSI-optimization is active (opt_val=0 is default)
new_plot        = 0;                        % do not start new plot
append_plot  	= 1;                        % append to previous plot    
display_plot  	= 1;                        % display plots 

% Conditions for saving displayed plots
mkdir('./study_cases/case_6_Partially_Ctr');
test_name       = './study_cases/case_6_Partially_Ctr/case_6';
lgd_loc51 = 'southeast';
lgd_loc52 = 'northeast';
    
main

