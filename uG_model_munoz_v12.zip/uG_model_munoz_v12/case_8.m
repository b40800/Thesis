 % Case scenario 8: Control by Injection of Reactive Power
 close all; clear all;
% Initial state
% Qinv = -1218
no_inv          = 1;               
save_clear      = 1;
opt_Pinv        = 0;                
save_appnd      = 0;
disp_plots      = 0;
S_DG            = 10000 - 1250i;     
S_Load          = -8000;            
S_ES            = 0;                
droop_main      = 1;
droop_Part      = 0;
opt_sel         = 2;
opt_val         = 1000;           

main

% Update variables with required value 
no_inv          = 0;                
save_clear      = 0;
opt_Pinv        = 1;                
disp_plots      = 1;    
mkdir('./study_cases/case_8_Reactive_Power');
test_name       = './study_cases/case_8_Reactive_Power/case_8_1';
lgd_loc51 = 'southeast';
lgd_loc52 = 'northeast';

main
%angle(I1(2))                %-500i:  300|-0.2783; 800|-0.3427; 1000|-0.3920
                             %-1250i: 300|-0.6258; 800|-0.8123; 1000|-1.1589
close all; clear all;


% Initial state
% Qinv = 1022
no_inv          = 1;               
save_clear      = 1;
opt_Pinv        = 0;                
save_appnd      = 0;
disp_plots      = 0;
S_DG            = 8000 - 1250i;     
S_Load          = -10000;            
S_ES            = 0;                
droop_main      = 1;
droop_Part      = 0;
opt_sel         = 2;
opt_val         = -1000;

main

% Update variables with required value 
no_inv          = 0;                
save_clear      = 0;
opt_Pinv        = 1;                
disp_plots      = 1;    
test_name       = './study_cases/case_8_Reactive_Power/case_8_2';
lgd_loc51 = 'northeast';
lgd_loc52 = 'southeast';

main


