% Plot fully and partially controllable units
close all; clear all;
global u0 p0_DG Kp Ctrl_DGs Ctrl_Unit_p cpwr_band

droop_DG        = 1;
droop_Part      = 1;

u0          = 230;
S0          = ones(2,1);
S0(1:2)     = 10000 - 1000i;             % set initial value of S for 2 DG units
U0          = ones(size(S0))*u0;        % initial guess for voltage of every unit
u_min       = 0.9*u0;
u_max       = 1.1*u0;
p0_DG       = real(S0(1));
Ctrl_DGs    = 1;                    %Fully controllable (DG1..DGn)
Ctrl_Unit_p = 2;                    %Partially controllable (DG1..DGn) 10V constant band
cpwr_band   = 0.1;                  % Percentage of constant-voltage band
p_nom       = 10000;
Kp          = -p_nom/(u_max-u_min);

% plot variables
U1      = zeros(2,1);
P1      = zeros(2,1);
U1(:,1) = U0;
P1(:,1) = real(S0);
for U=u0:-1:u_min
    S1 = droop_control(ones(length(U0))*U, S0);
    U1(:,end+1) = ones(size(U0))*U;
    P1(:,end+1) = real(S1);
end
    
% plot variables
U2      = zeros(2,1);
P2      = zeros(2,1);
U2(:,1) = U0;
P2(:,1) = real(S0);
for U=u0:u_max
    S1 = droop_control(ones(length(U0))*U, S0);
    U2(:,end+1) = ones(size(U0))*U;
    P2(:,end+1) = real(S1);
end

Power_max = max([P1(1,:) P1(2,:) P2(1,:) P2(2,:)]);

figure('Position', [100 50 1000 600]);
subplot('position',[0.09 0.13 0.88 0.85]);
h1 = plot( abs(U1(1,:)), P1(1,:)/Power_max, 'Color', [0 0.447 0.741], 'LineWidth',5); hold on;
plot( abs(U2(1,:)), P2(1,:)/Power_max, 'Color', [0 0.447 0.741],'LineWidth',5); hold on;
h2 = plot( abs(U1(2,:)), P1(2,:)/Power_max, 'Color', [0.85 0.325 0.098],'LineWidth',5); hold on;
plot( abs(U2(2,:)), P2(2,:)/Power_max, 'Color', [0.85 0.325 0.098],'LineWidth',5);

set(gca,'Fontsize',18);
xlabel('U [ V ]'); ylabel('P / P_M_A_X');
legend([h1 h2],{'Fully Controllable','Partially Controllable'},'Fontsize',18);

mkdir('./study_cases/case_6_Partially_Ctr');
saveas(gcf,'./study_cases/case_6_Partially_Ctr/case_droop_partially.png');






