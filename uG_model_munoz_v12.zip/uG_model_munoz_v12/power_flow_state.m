function [U_o, S_o, S_histo] = power_flow_state(U_i, S_i, max_iter, tol)
% POWER_FLOW  This function resolves non-linear system of equations for
%             power flow in steady state conditions (no transient changes
%             in U due to load or power generation are accounted for).
%             It takes U(1:2) and S(3:N), as well as U0(1:N) as knowns, and 
%             iterates to solve and get U(3:N) and S(1:2) (unknowns)

global H H_in display_debug

if display_debug
    S_histo = zeros(1,1);               % declare array to store data
else
    S_histo = NaN;                      % declare dummy variable
end

Uk      = U_i;
S_ic    = conj(S_i);

for k=1:max_iter
    
    Ik  = H*Uk;
    Sk 	= Uk.*conj(Ik);
    
    if display_debug
        S_histo(end+1) = Sk(1);
    end
    
    if( max( abs(abs(S_i(3:end))-abs(Sk(3:end)))) < tol)
        break;
    end
    
    Skc         = conj(Sk);
    Uk(3:end)   = H_in*( ( S_ic(3:end)-Skc(3:end) ) ./ conj(Uk(3:end) ) ) + Uk(3:end);
    
end

U_o = Uk;
S_o = Sk;

end
