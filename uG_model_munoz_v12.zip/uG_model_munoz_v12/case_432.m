% Case scenario 431: Length of distribution lines

% Close to limit
close all; clear all;
% Initial state (no VSI, droop_DG)
compute_H       = 1;
len_Line        = 1500;                     % simulation shows instablility with this value
P_Load          = -7000;                    % starting Load power (consider S_DG0 = 10000-1300i)
new_plot        = 1;                        % start new plot
append_plot  	= 0;                        % do not append to previous plot    
display_plot  	= 0;                        % do not display plots 

main

% Update variables with required value 
compute_H       = 0;
active_VSI     	= 1;
opt_VSI         = 1;
new_plot        = 0;
append_plot  	= 1; 
display_plot    = 1;     
mkdir('./study_cases/case_432_length_lines');
test_name       = './study_cases/case_432_length_lines/case_432_1';
lgd_loc51 = 'northeast';
lgd_loc52 = 'southeast';

main

% Closer to limit
close all; clear all;
% Initial state (no VSI, droop_DG)
compute_H       = 1;
len_Line        = 1850;                     % The simulation shows instablility with this value
                                            % stability limit is 1850 (~400 droop iterations)
                                            % with a value of 1950 power flow-droop control without VSI diverges to
                                            % disproportionate PCC voltage of 750V does not complete optimization
P_Load          = -7000;                    % starting Load power (consider S_DG0 = 10000-1300i)
new_plot        = 1;                        % start new plot
append_plot  	= 0;                        % do not append to previous plot    
display_plot  	= 0;                        % do not display plots 

main

% Update variables with required value 
compute_H       = 0;
active_VSI     	= 1;
opt_VSI         = 1;
new_plot        = 0;
append_plot  	= 1; 
display_plot    = 1;    
test_name       = './study_cases/case_432_length_lines/case_432_2';
lgd_loc51 = 'northeast';
lgd_loc52 = 'southeast';

main

% Compute H again with default values to restore default model
close all; clear all;
compute_H       = 1;

main
