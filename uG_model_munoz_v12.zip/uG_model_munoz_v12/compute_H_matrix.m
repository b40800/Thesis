function [H, H_in]= get_H_matrix(model)
% ANALYZE_MODEL  This function executes Matlab command power_analyze, to get 
%                the state-space representation of the given Simulink model.
%                Using the out

global w 

sps = power_analyze(model,'structure');

T = 1i*w*eye(size(sps.A));

H       = (sps.C/(T-sps.A))*sps.B + sps.D;      % Our system of equations takes into account 
                                                % the fundamental angular frequency (dq frame)
H_in    = pinv(H(3:end,3:end));                 % only 3:end nodes are required for power flow

end


