% Case scenario 2: Load demand exceeds Distributed Generation 
close all; clear all;
% Initial state (no VSI, droop_DG) 
P_Load          = -13000;                   % starting Load power (consider S_DG0 = 10000-1300i)
new_plot        = 1;                        % start new plot
append_plot  	= 0;                        % do not append to previous plot    
display_plot  	= 0;                        % do not display plots 

main

% Update variables with required value 
active_VSI     	= 1;                        % operate with VSI
opt_VSI         = 1;                        % VSI-optimization is active (opt_val=0 is default)
P_Load          = -13000;                   % starting Load power (consider S_DG0 = 10000-1300i)
new_plot        = 0;                        % start new plot
append_plot  	= 1;                        % append to previous plot    
display_plot  	= 1;                        % display plots  

% Conditions for saving displayed plots
mkdir('./study_cases/case_2_Load_exceeds');
test_name       = './study_cases/case_2_Load_exceeds/case_2';

main

% take table_1 from environment and write excel file
writetable(table_1,'./study_cases/case_2_Load_exceeds/table_results.xlsx'); 