% Case scenario 0: Default configuration, effect of droop control, VSI optimization

close all; clear all;
% Default case: No Inverter, DG droop control
new_plot        = 1;                        % start new plot
display_plot  	= 1;                        % display plots

% Conditions for saving displayed plots
mkdir('./study_cases/case_0_droop_effect'); 
test_name = './study_cases/case_0_droop_effect/case_0_1';
lgd_loc51 = 'southeast';
lgd_loc52 = 'northeast';

main


close all; clear all;
% No droop control, No Inverter,
droop_DG        = 0;                        % all droop controllers inactive 
droop_ES        = 0;                        % all droop controllers inactive
droop_Part      = 0;                        % all droop controllers inactive
new_plot        = 1;                        % start new plot
append_plot  	= 0;                        % do not append to previous plot    
display_plot  	= 0;                        % do not display plots 

main

% Update variables with required value
% Default case: No Inverter, DG droop control
droop_DG        = 1;                       	% activate droop_DG=1
new_plot        = 0;                        % do not start new plot
append_plot  	= 1;                        % append to previous plot
display_plot  	= 1;                        % display plots

% Conditions for saving displayed plots
mkdir('./study_cases/case_0_droop_effect'); 
test_name = './study_cases/case_0_droop_effect/case_0_2';
lgd_loc51 = 'southeast';
lgd_loc52 = 'northeast';

main

close all; clear all;
% No droop control, No Inverter,
droop_DG        = 0;                        % all droop controllers inactive 
droop_ES        = 0;                        % all droop controllers inactive
droop_Part      = 0;                        % all droop controllers inactive 
new_plot        = 1;                        % start new plot
append_plot  	= 0;                        % do not append to previous plot    
display_plot  	= 0;                        % do not display plots 

main

% Update variables with required value
% VSI Optimization 
active_VSI     	= 1;                        % operate with VSI
opt_VSI         = 1;                        % VSI-optimization is active (opt_val=0 is default)
droop_DG        = 1;                       	% activate droop_DG=1
new_plot        = 0;                        % do not start new plot
append_plot  	= 1;                        % append to previous plot
display_plot   	= 1;

% Conditions for saving displayed plots
mkdir('./study_cases/case_0_droop_effect');
test_name = './study_cases/case_0_droop_effect/case_0_3';
lgd_loc51 = 'southeast';
lgd_loc52 = 'northeast';

main

% take table_1 from environment and write excel file
writetable(table_1,'./study_cases/case_0_droop_effect/table_results.xlsx'); 

